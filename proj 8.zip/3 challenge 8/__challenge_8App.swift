//
//  __challenge_8App.swift
//  3 challenge 8
//
//  Created by Khayra Anandini Handoko on 31/8/23.
//

import SwiftUI

@main
struct __challenge_8App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
